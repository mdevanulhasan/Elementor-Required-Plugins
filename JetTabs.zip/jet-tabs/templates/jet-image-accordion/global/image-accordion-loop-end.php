<?php
/**
 * Image accordion list end template
 */
?>
</div>

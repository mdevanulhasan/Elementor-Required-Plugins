( function( $, JetReviewsAdminConfig ) {

	'use strict';

} )( jQuery, window.JetReviewsAdminConfig );

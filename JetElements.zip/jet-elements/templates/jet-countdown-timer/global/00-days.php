<div class="jet-countdown-timer__item item-days">
	<div class="jet-countdown-timer__item-value" data-value="days"><?php echo $this->date_placeholder(); ?></div>
	<?php $this->_html( 'label_days', '<div class="jet-countdown-timer__item-label">%s</div>' ); ?>
</div>

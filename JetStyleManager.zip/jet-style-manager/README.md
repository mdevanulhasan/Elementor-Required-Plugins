# Jet Style Manager

## 1.3.3
* UPD: sanitize function

## 1.3.2
* FIX: WP error in font manager

## 1.3.1
* FIX: WP error in font manager

## 1.3.0
* FIX: Saving post meta
* FIX: Font manager

## 1.2.0
* ADD: Integrated google fonts in typography control

## 1.1.6
* ADD: hooks for implementing custom sections and controls

## 1.1.5
* FIX: Block wrapper

## 1.1.4
* FIX: Typography control

## 1.1.3
* FIX: Up init action priority in gutenberg style manager

## 1.1.2
* FIX: Condition logic in gutenberg style manager

## 1.1.1
* FIX: Elementor compatibility

## 1.1.0
* ADD: Gutenberg compatibility
* ADD: Languages default file

## 1.0.0
* Initial release

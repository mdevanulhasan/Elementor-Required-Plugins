<?php
/**
 * JetWooBuilder Single Product Price template.
 */

woocommerce_template_single_price();
<?php
/**
 * JetWooBuilder Single Upsells template.
 */

woocommerce_upsell_display();

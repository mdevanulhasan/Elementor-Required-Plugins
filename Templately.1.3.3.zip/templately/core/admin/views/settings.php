<div class="templately-admin-body">
    <div id="templatelyAdmin">
        <div class="templately-admin-preloader" style="padding: 100px;min-height: 100%;box-sizing: border-box;text-align: center;">
            <img width="130px" src="<?php echo TEMPLATELY_ASSETS . 'images/loading-logo.gif'; ?>" alt="">
        </div>
    </div>
</div>